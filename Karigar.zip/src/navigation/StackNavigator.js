import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import OrderScreen from '../User/screens/OrderScreen';
import Orderpage from '../User/screens/Orderpage';
import ScreenZoom from '../User/screens/ScreenZoom';


const Stack = createNativeStackNavigator();

const StackNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName=""
      screenOptions={{
        headerShown: false,
      }}>
      {/* <Stack.Screen name="Home" component={HomeScreen} />
     */}

      <Stack.Screen name="OrderScreen" component={OrderScreen} />
      <Stack.Screen name="Orderpage" component={Orderpage} />
      <Stack.Screen name="ScreenZoom" component={ScreenZoom} />



    </Stack.Navigator>
  );
};

export default StackNavigator;