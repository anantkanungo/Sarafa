import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';;
import KarigarInfo from '../User/screens/KarigarIfo';
import Catalogs from '../components/home/Catalogs';
import Your_Order from '../User/screens/Your_Order';
import Orderpage from '../User/screens/Orderpage';
import ScreenZoom from '../User/screens/ScreenZoom';
import Karigar_Details from '../User/screens/Karigar_Details';
import TaskAssign from '../User/screens/TaskAssign'


const Stack = createNativeStackNavigator();

const StackNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName="Catalogs"
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name="KarigarInfo" component={KarigarInfo} />
      <Stack.Screen name="Catalogs" component={Catalogs} />
      <Stack.Screen name="Your_Order" component={Your_Order} />
      <Stack.Screen name="Orderpage" component={Orderpage} />
      <Stack.Screen name="ScreenZoom" component={ScreenZoom} />
      <Stack.Screen name="Karigar_Details" component={Karigar_Details} />
      <Stack.Screen name="TaskAssign" component={TaskAssign} />



    </Stack.Navigator>
  );
};

export default StackNavigator;